<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
    <meta name="description" content="<?php echo $__env->yieldContent('meta_description', $settings['meta_description'] ?? ''); ?>">
    <meta name="keywords" content="<?php echo $__env->yieldContent('meta_keywords', $settings['meta_keywords'] ?? ''); ?>">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', $settings['site_name'] ?? 'CorpusFeed'); ?> - <?php echo e($settings['site_name'] ?? 'CorpusFeed'); ?></title>
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e($settings['site_favicon'] ? asset('storage/'.$settings['site_favicon']) : asset('images/favicon.png')); ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,200..800&display=swap" rel="stylesheet">
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet" media="screen">
    <link href="<?php echo e(asset('css/slicknav.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/swiper-bundle.min.css')); ?>">
    <link href="<?php echo e(asset('css/all.min.css')); ?>" rel="stylesheet" media="screen">
    <link href="<?php echo e(asset('css/animate.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/magnific-popup.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/mousecursor.css')); ?>">
    <link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet" media="screen">
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>

    <!-- Preloader -->
    <div class="preloader">
        <div class="loading-container">
            <div class="loading"></div>
            <div id="loading-icon"><img src="<?php echo e(asset('images/loader.svg')); ?>" alt=""></div>
        </div>
    </div>

    <?php echo $__env->make('layouts.partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('layouts.partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <script src="<?php echo e(asset('js/jquery-3.7.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/validator.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.slicknav.js')); ?>"></script>
    <script src="<?php echo e(asset('js/swiper-bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.waypoints.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.counterup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.magnific-popup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/SmoothScroll.js')); ?>"></script>
    <script src="<?php echo e(asset('js/parallaxie.js')); ?>"></script>
    <script src="<?php echo e(asset('js/gsap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/magiccursor.js')); ?>"></script>
    <script src="<?php echo e(asset('js/SplitText.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/ScrollTrigger.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/wow.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/function.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\Users\USER PC\Desktop\corpus-feed\corpusfeed\resources\views\layouts\app.blade.php ENDPATH**/ ?>