<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>

<!-- Stats Grid -->
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(190px,1fr));gap:16px;margin-bottom:24px;">

    <div class="stat-card">
        <div class="stat-icon"><i class="fa-solid fa-newspaper"></i></div>
        <div>
            <div class="stat-value"><?php echo e($stats['posts']); ?></div>
            <div class="stat-label">Published Posts</div>
        </div>
    </div>

    <div class="stat-card">
        <div class="stat-icon" style="background:linear-gradient(135deg,#374151,#6b7280);"><i class="fa-solid fa-file-pen"></i></div>
        <div>
            <div class="stat-value"><?php echo e($stats['drafts']); ?></div>
            <div class="stat-label">Draft Posts</div>
        </div>
    </div>

    <div class="stat-card">
        <div class="stat-icon"><i class="fa-solid fa-briefcase"></i></div>
        <div>
            <div class="stat-value"><?php echo e($stats['services']); ?></div>
            <div class="stat-label">Active Services</div>
        </div>
    </div>

    <div class="stat-card">
        <div class="stat-icon"><i class="fa-solid fa-users"></i></div>
        <div>
            <div class="stat-value"><?php echo e($stats['team']); ?></div>
            <div class="stat-label">Team Members</div>
        </div>
    </div>

    <div class="stat-card">
        <div class="stat-icon" style="background:linear-gradient(135deg,#92400e,#d97706);"><i class="fa-solid fa-star"></i></div>
        <div>
            <div class="stat-value"><?php echo e($stats['testimonials']); ?></div>
            <div class="stat-label">Testimonials</div>
        </div>
    </div>

    <div class="stat-card">
        <div class="stat-icon" style="background:linear-gradient(135deg,#1e3a8a,#3b82f6);"><i class="fa-solid fa-circle-question"></i></div>
        <div>
            <div class="stat-value"><?php echo e($stats['faqs']); ?></div>
            <div class="stat-label">Active FAQs</div>
        </div>
    </div>

    <div class="stat-card">
        <div class="stat-icon" style="background:linear-gradient(135deg,#7f1d1d,#ef4444);"><i class="fa-solid fa-envelope"></i></div>
        <div>
            <div class="stat-value"><?php echo e($stats['unread_messages']); ?></div>
            <div class="stat-label">Unread Messages</div>
        </div>
    </div>

    <div class="stat-card">
        <div class="stat-icon"><i class="fa-solid fa-at"></i></div>
        <div>
            <div class="stat-value"><?php echo e($stats['subscribers']); ?></div>
            <div class="stat-label">Subscribers</div>
        </div>
    </div>

</div>

<!-- Quick Actions -->
<div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:24px;">
    <a href="<?php echo e(route('admin.posts.create')); ?>" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> New Post</a>
    <a href="<?php echo e(route('admin.services.create')); ?>" class="btn btn-secondary btn-sm"><i class="fa-solid fa-plus"></i> New Service</a>
    <a href="<?php echo e(route('admin.team.create')); ?>" class="btn btn-secondary btn-sm"><i class="fa-solid fa-plus"></i> Add Team Member</a>
    <a href="<?php echo e(route('admin.testimonials.create')); ?>" class="btn btn-secondary btn-sm"><i class="fa-solid fa-plus"></i> Add Testimonial</a>
    <a href="<?php echo e(route('admin.faqs.create')); ?>" class="btn btn-secondary btn-sm"><i class="fa-solid fa-plus"></i> Add FAQ</a>
    <a href="<?php echo e(route('admin.settings.index')); ?>" class="btn btn-accent btn-sm"><i class="fa-solid fa-gear"></i> Site Settings</a>
</div>

<!-- Content Tables -->
<div class="form-row cols-2">
    <!-- Recent Posts -->
    <div class="card">
        <div class="card-header">
            <h2>Recent Posts</h2>
            <a href="<?php echo e(route('admin.posts.index')); ?>" class="btn btn-secondary btn-sm">View All</a>
        </div>
        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Status</th>
                        <th>Views</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $recentPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><a href="<?php echo e(route('admin.posts.edit', $post)); ?>" style="color:inherit;text-decoration:none;font-weight:500;"><?php echo e(Str::limit($post->title, 38)); ?></a></td>
                        <td>
                            <?php if($post->status === 'published'): ?> <span class="badge badge-success">Live</span>
                            <?php elseif($post->status === 'draft'): ?> <span class="badge badge-secondary">Draft</span>
                            <?php else: ?> <span class="badge badge-warning">Scheduled</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e(number_format($post->views)); ?></td>
                        <td style="color:var(--text-muted);font-size:13px;"><?php echo e($post->published_at?->format('M d') ?? '—'); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="4" style="text-align:center;padding:32px;color:var(--text-muted);">No posts yet. <a href="<?php echo e(route('admin.posts.create')); ?>">Create one</a></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Recent Messages -->
    <div class="card">
        <div class="card-header">
            <h2>
                Recent Messages
                <?php if($stats['unread_messages'] > 0): ?>
                <span class="badge badge-danger" style="margin-left:6px;"><?php echo e($stats['unread_messages']); ?> unread</span>
                <?php endif; ?>
            </h2>
            <a href="<?php echo e(route('admin.messages.index')); ?>" class="btn btn-secondary btn-sm">View All</a>
        </div>
        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>From</th>
                        <th>Subject</th>
                        <th>Status</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $recentMessages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><a href="<?php echo e(route('admin.messages.show', $msg)); ?>" style="color:inherit;text-decoration:none;font-weight:<?php echo e($msg->status === 'unread' ? '700' : '400'); ?>;"><?php echo e($msg->name); ?></a></td>
                        <td style="font-size:13px;"><?php echo e(Str::limit($msg->subject ?? 'No subject', 28)); ?></td>
                        <td>
                            <?php if($msg->status === 'unread'): ?> <span class="badge badge-danger">New</span>
                            <?php elseif($msg->status === 'read'): ?> <span class="badge badge-info">Read</span>
                            <?php else: ?> <span class="badge badge-success">Replied</span>
                            <?php endif; ?>
                        </td>
                        <td style="color:var(--text-muted);font-size:13px;"><?php echo e($msg->created_at->format('M d')); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="4" style="text-align:center;padding:32px;color:var(--text-muted);">No messages yet.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER PC\Desktop\corpus-feed\corpusfeed\resources\views\admin\dashboard.blade.php ENDPATH**/ ?>