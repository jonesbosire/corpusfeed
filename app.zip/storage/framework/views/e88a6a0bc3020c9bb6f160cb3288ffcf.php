<header class="main-header">
    <div class="header-sticky bg-section">
        <nav class="navbar navbar-expand-lg">
            <div class="container">
                <!-- Logo -->
                <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
                    <?php if(!empty($settings['site_logo'])): ?>
                        <img src="<?php echo e(asset('storage/'.$settings['site_logo'])); ?>" alt="<?php echo e($settings['site_name'] ?? 'CorpusFeed'); ?>">
                    <?php else: ?>
                        <img src="<?php echo e(asset('images/logo.svg')); ?>" alt="<?php echo e($settings['site_name'] ?? 'CorpusFeed'); ?>">
                    <?php endif; ?>
                </a>

                <!-- Main Menu -->
                <div class="collapse navbar-collapse main-menu">
                    <div class="nav-menu-wrapper">
                        <ul class="navbar-nav mr-auto" id="menu">
                            <li class="nav-item <?php echo e(request()->routeIs('home') ? 'active' : ''); ?>">
                                <a class="nav-link" href="<?php echo e(route('home')); ?>">Home</a>
                            </li>
                            <li class="nav-item <?php echo e(request()->routeIs('about') ? 'active' : ''); ?>">
                                <a class="nav-link" href="<?php echo e(route('about')); ?>">About Us</a>
                            </li>
                            <li class="nav-item <?php echo e(request()->routeIs('services.*') ? 'active' : ''); ?>">
                                <a class="nav-link" href="<?php echo e(route('services.index')); ?>">Services</a>
                            </li>
                            <li class="nav-item <?php echo e(request()->routeIs('blog.*') ? 'active' : ''); ?>">
                                <a class="nav-link" href="<?php echo e(route('blog.index')); ?>">Blog</a>
                            </li>
                            <li class="nav-item submenu <?php echo e(request()->routeIs('team') || request()->routeIs('faqs') ? 'active' : ''); ?>">
                                <a class="nav-link" href="#">Pages</a>
                                <ul>
                                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('team')); ?>">Our Team</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('faqs')); ?>">FAQs</a></li>
                                </ul>
                            </li>
                            <li class="nav-item <?php echo e(request()->routeIs('contact') ? 'active' : ''); ?>">
                                <a class="nav-link" href="<?php echo e(route('contact')); ?>">Contact Us</a>
                            </li>
                        </ul>
                    </div>
                    <div class="header-btn">
                        <a href="<?php echo e(route('contact')); ?>" class="btn-default btn-highlighted">Get Started</a>
                    </div>
                </div>
                <div class="navbar-toggle"></div>
            </div>
        </nav>
        <div class="responsive-menu"></div>
    </div>
</header>
<?php /**PATH C:\Users\USER PC\Desktop\corpus-feed\corpusfeed\resources\views\layouts\partials\header.blade.php ENDPATH**/ ?>