<?php $__env->startSection('title', isset($testimonial) ? 'Edit Testimonial' : 'New Testimonial'); ?>
<?php $__env->startSection('content'); ?>
<form method="POST" action="<?php echo e(isset($testimonial) ? route('admin.testimonials.update', $testimonial) : route('admin.testimonials.store')); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php if(isset($testimonial)): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

    <div class="form-row cols-2" style="align-items:start;">
        <div class="card">
            <div class="card-header"><h2>Testimonial</h2></div>
            <div class="card-body">
                <div class="form-row cols-2">
                    <div class="form-group">
                        <label class="form-label">Client Name *</label>
                        <input type="text" name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            value="<?php echo e(old('name', $testimonial->name ?? '')); ?>" required>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Role</label>
                        <input type="text" name="role" class="form-control" value="<?php echo e(old('role', $testimonial->role ?? '')); ?>">
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">Company</label>
                    <input type="text" name="company" class="form-control" value="<?php echo e(old('company', $testimonial->company ?? '')); ?>">
                </div>
                <div class="form-group">
                    <label class="form-label">Testimonial Content *</label>
                    <textarea name="content" class="form-control" rows="5" required><?php echo e(old('content', $testimonial->content ?? '')); ?></textarea>
                    <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label class="form-label">Rating (1-5)</label>
                    <select name="rating" class="form-control">
                        <?php for($i=5;$i>=1;$i--): ?>
                        <option value="<?php echo e($i); ?>" <?php echo e(old('rating', $testimonial->rating ?? 5) == $i ? 'selected' : ''); ?>><?php echo e($i); ?> Stars</option>
                        <?php endfor; ?>
                    </select>
                </div>
            </div>
        </div>

        <div style="display:flex;flex-direction:column;gap:20px;">
            <div class="card">
                <div class="card-header"><h2>Settings</h2></div>
                <div class="card-body">
                    <div class="form-group">
                        <label class="form-label">Status</label>
                        <select name="status" class="form-control">
                            <option value="active" <?php echo e(old('status', $testimonial->status ?? 'active') === 'active' ? 'selected' : ''); ?>>Active</option>
                            <option value="inactive" <?php echo e(old('status', $testimonial->status ?? '') === 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                        </select>
                    </div>
                    <div style="display:flex;gap:10px;">
                        <button type="submit" class="btn btn-primary" style="flex:1;">
                            <i class="fa-solid fa-floppy-disk"></i> <?php echo e(isset($testimonial) ? 'Update' : 'Save'); ?>

                        </button>
                        <a href="<?php echo e(route('admin.testimonials.index')); ?>" class="btn btn-secondary">Cancel</a>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-header"><h2>Client Photo</h2></div>
                <div class="card-body">
                    <?php if(isset($testimonial) && $testimonial->photo): ?>
                    <img src="<?php echo e(asset('storage/'.$testimonial->photo)); ?>" class="image-preview" id="imgPreview">
                    <?php else: ?>
                    <div id="previewWrap" style="display:none;margin-bottom:10px;"><img id="imgPreview" class="image-preview"></div>
                    <?php endif; ?>
                    <input type="file" name="photo" class="form-control" accept="image/*" style="margin-top:10px;" onchange="previewImg(this)">
                </div>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
function previewImg(input) {
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = e => {
            const img = document.getElementById('imgPreview');
            const wrap = document.getElementById('previewWrap');
            img.src = e.target.result;
            if (wrap) wrap.style.display = 'block';
        };
        reader.readAsDataURL(input.files[0]);
    }
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER PC\Desktop\corpus-feed\corpusfeed\resources\views\admin\testimonials\form.blade.php ENDPATH**/ ?>