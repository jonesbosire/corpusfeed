<?php $__env->startSection('title', 'Tags'); ?>
<?php $__env->startSection('content'); ?>
<div class="form-row cols-2" style="align-items:start;">
    <div class="card">
        <div class="card-header"><h2>All Tags</h2></div>
        <div class="table-wrapper">
            <table>
                <thead><tr><th>Name</th><th>Slug</th><th>Posts</th><th>Actions</th></tr></thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td style="font-weight:500;"><?php echo e($tag->name); ?></td>
                        <td><code><?php echo e($tag->slug); ?></code></td>
                        <td><?php echo e($tag->posts_count); ?></td>
                        <td>
                            <div style="display:flex;gap:6px;">
                                <a href="<?php echo e(route('admin.tags.edit', $tag)); ?>" class="btn btn-secondary btn-sm btn-icon"><i class="fa-solid fa-pen"></i></a>
                                <form method="POST" action="<?php echo e(route('admin.tags.destroy', $tag)); ?>" onsubmit="return confirm('Delete?')">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm btn-icon"><i class="fa-solid fa-trash"></i></button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="4" class="text-center" style="color:#888;padding:32px;">No tags yet.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card">
        <div class="card-header"><h2><?php echo e(isset($tag) ? 'Edit Tag' : 'New Tag'); ?></h2></div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(isset($tag) ? route('admin.tags.update', $tag) : route('admin.tags.store')); ?>">
                <?php echo csrf_field(); ?>
                <?php if(isset($tag)): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
                <div class="form-group">
                    <label class="form-label">Name *</label>
                    <input type="text" name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        value="<?php echo e(old('name', $tag->name ?? '')); ?>" required>
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div style="display:flex;gap:10px;">
                    <button type="submit" class="btn btn-primary"><?php echo e(isset($tag) ? 'Update' : 'Create'); ?></button>
                    <?php if(isset($tag)): ?>
                    <a href="<?php echo e(route('admin.tags.index')); ?>" class="btn btn-secondary">Cancel</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER PC\Desktop\corpus-feed\corpusfeed\resources\views\admin\tags\index.blade.php ENDPATH**/ ?>