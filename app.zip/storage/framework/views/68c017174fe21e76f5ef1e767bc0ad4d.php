<?php $__env->startSection('title', 'Blog Posts'); ?>

<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <h2>Blog Posts</h2>
        <a href="<?php echo e(route('admin.posts.create')); ?>" class="btn btn-primary btn-sm">
            <i class="fa-solid fa-plus"></i> New Post
        </a>
    </div>
    <div class="card-body" style="padding:0;">
        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Category</th>
                        <th>Status</th>
                        <th>Views</th>
                        <th>Published</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td style="font-weight:500;"><?php echo e(Str::limit($post->title, 50)); ?></td>
                        <td><?php echo e($post->category?->name ?? '—'); ?></td>
                        <td>
                            <?php if($post->status === 'published'): ?>
                                <span class="badge badge-success">Published</span>
                            <?php elseif($post->status === 'draft'): ?>
                                <span class="badge badge-secondary">Draft</span>
                            <?php else: ?>
                                <span class="badge badge-warning">Scheduled</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($post->views); ?></td>
                        <td><?php echo e($post->published_at?->format('M d, Y') ?? '—'); ?></td>
                        <td>
                            <div style="display:flex;gap:6px;">
                                <a href="<?php echo e(route('admin.posts.edit', $post)); ?>" class="btn btn-secondary btn-sm btn-icon" title="Edit">
                                    <i class="fa-solid fa-pen"></i>
                                </a>
                                <a href="<?php echo e(route('blog.show', $post->slug)); ?>" target="_blank" class="btn btn-secondary btn-sm btn-icon" title="View">
                                    <i class="fa-solid fa-arrow-up-right-from-square"></i>
                                </a>
                                <form method="POST" action="<?php echo e(route('admin.posts.destroy', $post)); ?>" onsubmit="return confirm('Delete this post?')">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm btn-icon" title="Delete">
                                        <i class="fa-solid fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6">
                            <div class="empty-state">
                                <i class="fa-solid fa-newspaper"></i>
                                <h3>No posts yet</h3>
                                <p>Create your first blog post</p>
                                <a href="<?php echo e(route('admin.posts.create')); ?>" class="btn btn-primary" style="margin-top:12px;">New Post</a>
                            </div>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if($posts->hasPages()): ?>
        <div style="padding:16px 24px;"><?php echo e($posts->links()); ?></div>
        <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER PC\Desktop\corpus-feed\corpusfeed\resources\views\admin\posts\index.blade.php ENDPATH**/ ?>