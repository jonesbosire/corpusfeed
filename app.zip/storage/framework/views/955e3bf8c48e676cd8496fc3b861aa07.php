
<?php $__env->startSection('title', isset($service) ? 'Edit Service' : 'New Service'); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@toast-ui/editor@3/dist/toastui-editor.min.css">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<form method="POST" action="<?php echo e(isset($service) ? route('admin.services.update', $service) : route('admin.services.store')); ?>" enctype="multipart/form-data" id="svcForm">
    <?php echo csrf_field(); ?>
    <?php if(isset($service)): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

    <div class="form-row cols-2" style="align-items:start;">
        <div style="display:flex;flex-direction:column;gap:20px;">
            <div class="card">
                <div class="card-header"><h2>Service Details</h2></div>
                <div class="card-body">
                    <div class="form-group">
                        <label class="form-label">Title *</label>
                        <input type="text" name="title" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            value="<?php echo e(old('title', $service->title ?? '')); ?>" required>
                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Icon Class <span style="font-weight:400;color:#888;">(Font Awesome, e.g. fa-leaf)</span></label>
                        <input type="text" name="icon" class="form-control" placeholder="fa-leaf"
                            value="<?php echo e(old('icon', $service->icon ?? '')); ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Short Description</label>
                        <textarea name="short_description" class="form-control" rows="3"><?php echo e(old('short_description', $service->short_description ?? '')); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Full Description</label>
                        <div id="editor"></div>
                        <input type="hidden" name="body" id="bodyInput">
                    </div>
                </div>
            </div>
        </div>

        <div style="display:flex;flex-direction:column;gap:20px;">
            <div class="card">
                <div class="card-header"><h2>Settings</h2></div>
                <div class="card-body">
                    <div class="form-group">
                        <label class="form-label">Status</label>
                        <select name="status" class="form-control">
                            <option value="active" <?php echo e(old('status', $service->status ?? 'active') === 'active' ? 'selected' : ''); ?>>Active</option>
                            <option value="inactive" <?php echo e(old('status', $service->status ?? '') === 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Sort Order</label>
                        <input type="number" name="order" class="form-control" value="<?php echo e(old('order', $service->order ?? 0)); ?>" min="0">
                    </div>
                    <div style="display:flex;gap:10px;margin-top:8px;">
                        <button type="submit" class="btn btn-primary" style="flex:1;">
                            <i class="fa-solid fa-floppy-disk"></i> <?php echo e(isset($service) ? 'Update' : 'Save'); ?>

                        </button>
                        <a href="<?php echo e(route('admin.services.index')); ?>" class="btn btn-secondary">Cancel</a>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-header"><h2>Featured Image</h2></div>
                <div class="card-body">
                    <?php if(isset($service) && $service->featured_image): ?>
                    <img src="<?php echo e(asset('storage/'.$service->featured_image)); ?>" class="image-preview" id="imgPreview">
                    <label style="display:flex;align-items:center;gap:8px;margin-top:10px;font-size:13px;cursor:pointer;">
                        <input type="checkbox" name="remove_featured_image" value="1"> Remove image
                    </label>
                    <?php else: ?>
                    <div id="previewWrap" style="display:none;margin-bottom:10px;">
                        <img id="imgPreview" class="image-preview">
                    </div>
                    <?php endif; ?>
                    <input type="file" name="featured_image" class="form-control" accept="image/*" onchange="previewImg(this)">
                </div>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/@toast-ui/editor@3/dist/toastui-editor-all.min.js"></script>
<script>
const editor = new toastui.Editor({
    el: document.querySelector('#editor'),
    height: '300px',
    initialEditType: 'wysiwyg',
    previewStyle: 'tab',
    initialValue: <?php echo json_encode(old('body', $service->body ?? '')); ?>,
});
document.getElementById('svcForm').addEventListener('submit', function() {
    document.getElementById('bodyInput').value = editor.getHTML();
});
function previewImg(input) {
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = e => {
            const img = document.getElementById('imgPreview');
            const wrap = document.getElementById('previewWrap');
            img.src = e.target.result;
            if (wrap) wrap.style.display = 'block';
        };
        reader.readAsDataURL(input.files[0]);
    }
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER PC\Desktop\corpus-feed\corpusfeed\resources\views\admin\services\form.blade.php ENDPATH**/ ?>