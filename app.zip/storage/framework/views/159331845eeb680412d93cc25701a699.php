<?php $__env->startSection('title', $service->title); ?>
<?php $__env->startSection('meta_description', $service->short_description); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('layouts.partials.page-header', [
        'pageTitle' => $service->title,
        'breadcrumbs' => [
            ['label' => 'Services', 'url' => route('services.index')],
            ['label' => $service->title, 'url' => route('services.show', $service->slug)]
        ]
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="page-service-single">
        <div class="container">
            <div class="row">
                <div class="col-xl-8">
                    <div class="service-single-content wow fadeInUp">
                        <?php if($service->featured_image): ?>
                        <div class="service-single-image mb-4">
                            <figure class="image-anime reveal">
                                <img src="<?php echo e(asset('storage/'.$service->featured_image)); ?>" alt="<?php echo e($service->title); ?>" class="img-fluid rounded">
                            </figure>
                        </div>
                        <?php endif; ?>

                        <div class="service-single-body">
                            <?php echo $service->body; ?>

                        </div>
                    </div>
                </div>

                <div class="col-xl-4">
                    <!-- Sidebar -->
                    <div class="service-sidebar wow fadeInUp" data-wow-delay="0.2s">
                        <!-- All Services -->
                        <?php if($allServices->count()): ?>
                        <div class="sidebar-widget">
                            <h3 class="widget-title">All Services</h3>
                            <ul class="services-list">
                                <?php $__currentLoopData = $allServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="<?php echo e($s->id === $service->id ? 'active' : ''); ?>">
                                    <a href="<?php echo e(route('services.show', $s->slug)); ?>"><?php echo e($s->title); ?></a>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>

                        <!-- Contact Box -->
                        <div class="sidebar-widget sidebar-contact-box">
                            <h3>Need Help?</h3>
                            <p>Contact us for more information about our services.</p>
                            <a href="<?php echo e(route('contact')); ?>" class="btn-default">Contact Us</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER PC\Desktop\corpus-feed\corpusfeed\resources\views\pages\services\show.blade.php ENDPATH**/ ?>