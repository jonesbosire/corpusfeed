<?php $__env->startSection('title', 'Our Services'); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('layouts.partials.page-header', [
        'pageTitle' => 'Our Services',
        'breadcrumbs' => [['label' => 'Services', 'url' => route('services.index')]]
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="page-services">
        <div class="container">
            <div class="row section-row">
                <div class="col-lg-12">
                    <div class="section-title section-title-center">
                        <h3 class="wow fadeInUp">Our Services</h3>
                        <h2 class="text-anime-style-3" data-cursor="-opaque">Delivering quality services with trusted expertise</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-xl-4 col-md-6">
                    <div class="service-item-gold wow fadeInUp" data-wow-delay="<?php echo e(($i % 3) * 0.2); ?>s">
                        <div class="service-item-image-gold">
                            <a href="<?php echo e(route('services.show', $service->slug)); ?>" data-cursor-text="View">
                                <figure>
                                    <?php if($service->featured_image): ?>
                                        <img src="<?php echo e(asset('storage/'.$service->featured_image)); ?>" alt="<?php echo e($service->title); ?>">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('images/service-image-1-gold.jpg')); ?>" alt="<?php echo e($service->title); ?>">
                                    <?php endif; ?>
                                </figure>
                            </a>
                        </div>
                        <div class="service-item-body-gold">
                            <div class="service-item-content-gold">
                                <h3><a href="<?php echo e(route('services.show', $service->slug)); ?>"><?php echo e($service->title); ?></a></h3>
                                <p><?php echo e(Str::limit($service->short_description, 120)); ?></p>
                            </div>
                            <div class="service-item-btn-gold">
                                <a href="<?php echo e(route('services.show', $service->slug)); ?>" class="readmore-btn">Read More</a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12">
                    <p class="text-center">No services available yet.</p>
                </div>
                <?php endif; ?>
            </div>
            <?php echo e($services->links()); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER PC\Desktop\corpus-feed\corpusfeed\resources\views\pages\services\index.blade.php ENDPATH**/ ?>