<?php $__env->startSection('title', 'Blog'); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('layouts.partials.page-header', [
        'pageTitle' => 'Our Blog',
        'breadcrumbs' => [['label' => 'Blog', 'url' => route('blog.index')]]
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="page-blog">
        <div class="container">
            <div class="row">
                <div class="col-xl-8">
                    <div class="row">
                        <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-md-6">
                            <div class="post-item wow fadeInUp" data-wow-delay="<?php echo e(($i % 2) * 0.2); ?>s">
                                <div class="post-item-box">
                                    <div class="post-featured-image">
                                        <a href="<?php echo e(route('blog.show', $post->slug)); ?>" data-cursor-text="View">
                                            <figure class="image-anime">
                                                <?php if($post->featured_image): ?>
                                                    <img src="<?php echo e(asset('storage/'.$post->featured_image)); ?>" alt="<?php echo e($post->title); ?>">
                                                <?php else: ?>
                                                    <img src="<?php echo e(asset('images/post-1.jpg')); ?>" alt="<?php echo e($post->title); ?>">
                                                <?php endif; ?>
                                            </figure>
                                        </a>
                                    </div>
                                    <div class="post-item-content">
                                        <div class="post-meta">
                                            <?php if($post->category): ?>
                                            <span class="post-cat"><?php echo e($post->category->name); ?></span>
                                            <?php endif; ?>
                                            <span class="post-date"><?php echo e($post->published_at?->format('M d, Y')); ?></span>
                                        </div>
                                        <h2><a href="<?php echo e(route('blog.show', $post->slug)); ?>"><?php echo e($post->title); ?></a></h2>
                                        <p><?php echo e(Str::limit($post->excerpt, 120)); ?></p>
                                    </div>
                                </div>
                                <div class="post-item-btn">
                                    <a href="<?php echo e(route('blog.show', $post->slug)); ?>" class="readmore-btn">read more</a>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col-12">
                            <p class="text-center">No posts published yet.</p>
                        </div>
                        <?php endif; ?>
                    </div>

                    <div class="pagination-wrapper mt-4">
                        <?php echo e($posts->links()); ?>

                    </div>
                </div>

                <div class="col-xl-4">
                    <!-- Sidebar -->
                    <div class="blog-sidebar">
                        <!-- Categories -->
                        <?php if($categories->count()): ?>
                        <div class="sidebar-widget wow fadeInUp">
                            <h3 class="widget-title">Categories</h3>
                            <ul class="category-list">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a href="<?php echo e(route('blog.index', ['category' => $cat->slug])); ?>">
                                        <?php echo e($cat->name); ?>

                                        <span>(<?php echo e($cat->posts_count); ?>)</span>
                                    </a>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>

                        <!-- Recent Posts -->
                        <?php if($recentPosts->count()): ?>
                        <div class="sidebar-widget wow fadeInUp" data-wow-delay="0.2s">
                            <h3 class="widget-title">Recent Posts</h3>
                            <ul class="recent-posts-list">
                                <?php $__currentLoopData = $recentPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <?php if($rp->featured_image): ?>
                                    <img src="<?php echo e(asset('storage/'.$rp->featured_image)); ?>" alt="<?php echo e($rp->title); ?>">
                                    <?php endif; ?>
                                    <div>
                                        <a href="<?php echo e(route('blog.show', $rp->slug)); ?>"><?php echo e(Str::limit($rp->title, 50)); ?></a>
                                        <span><?php echo e($rp->published_at?->format('M d, Y')); ?></span>
                                    </div>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER PC\Desktop\corpus-feed\corpusfeed\resources\views\pages\blog\index.blade.php ENDPATH**/ ?>