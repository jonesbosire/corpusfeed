<?php $__env->startSection('title', 'Services'); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h2>Services</h2>
        <a href="<?php echo e(route('admin.services.create')); ?>" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> New Service</a>
    </div>
    <div class="table-wrapper">
        <table>
            <thead><tr><th>Title</th><th>Status</th><th>Order</th><th>Actions</th></tr></thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td style="font-weight:500;"><?php echo e($service->title); ?></td>
                    <td><span class="badge <?php echo e($service->status === 'active' ? 'badge-success' : 'badge-secondary'); ?>"><?php echo e(ucfirst($service->status)); ?></span></td>
                    <td><?php echo e($service->order); ?></td>
                    <td>
                        <div style="display:flex;gap:6px;">
                            <a href="<?php echo e(route('admin.services.edit', $service)); ?>" class="btn btn-secondary btn-sm btn-icon"><i class="fa-solid fa-pen"></i></a>
                            <form method="POST" action="<?php echo e(route('admin.services.destroy', $service)); ?>" onsubmit="return confirm('Delete?')">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm btn-icon"><i class="fa-solid fa-trash"></i></button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="4"><div class="empty-state"><i class="fa-solid fa-briefcase"></i><h3>No services</h3><a href="<?php echo e(route('admin.services.create')); ?>" class="btn btn-primary" style="margin-top:12px;">Add Service</a></div></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER PC\Desktop\corpus-feed\corpusfeed\resources\views\admin\services\index.blade.php ENDPATH**/ ?>