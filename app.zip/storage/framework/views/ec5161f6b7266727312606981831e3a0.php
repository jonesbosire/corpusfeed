<?php $__env->startSection('title', 'Messages'); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header"><h2>Contact Messages</h2></div>
    <div class="table-wrapper">
        <table>
            <thead><tr><th>From</th><th>Email</th><th>Subject</th><th>Status</th><th>Date</th><th>Actions</th></tr></thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr style="<?php echo e($msg->status === 'unread' ? 'font-weight:600;' : ''); ?>">
                    <td><?php echo e($msg->name); ?></td>
                    <td><?php echo e($msg->email); ?></td>
                    <td><?php echo e(Str::limit($msg->subject ?? 'No subject', 40)); ?></td>
                    <td>
                        <?php if($msg->status === 'unread'): ?>
                            <span class="badge badge-danger">Unread</span>
                        <?php elseif($msg->status === 'read'): ?>
                            <span class="badge badge-info">Read</span>
                        <?php else: ?>
                            <span class="badge badge-success">Replied</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($msg->created_at->format('M d, Y')); ?></td>
                    <td>
                        <div style="display:flex;gap:6px;">
                            <a href="<?php echo e(route('admin.messages.show', $msg)); ?>" class="btn btn-secondary btn-sm btn-icon" title="View">
                                <i class="fa-solid fa-eye"></i>
                            </a>
                            <form method="POST" action="<?php echo e(route('admin.messages.destroy', $msg)); ?>" onsubmit="return confirm('Delete?')">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm btn-icon"><i class="fa-solid fa-trash"></i></button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6"><div class="empty-state"><i class="fa-solid fa-envelope"></i><h3>No messages yet</h3></div></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($messages->hasPages()): ?>
    <div style="padding:16px 24px;"><?php echo e($messages->links()); ?></div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER PC\Desktop\corpus-feed\corpusfeed\resources\views\admin\messages\index.blade.php ENDPATH**/ ?>