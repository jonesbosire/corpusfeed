<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>

    <!-- Hero Section -->
    <div class="hero-gold bg-section">
        <div class="hero-box-gold">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hero-content-gold">
                            <div class="section-title">
                                <h3 class="wow fadeInUp"><?php echo e($settings['site_tagline'] ?? 'Healthy Farms, Healthy Lives'); ?></h3>
                                <h1 class="text-anime-style-3" data-cursor="-opaque"><?php echo e($settings['hero_title'] ?? 'Growing pure organic goodness for a healthier tomorrow'); ?></h1>
                                <p class="wow fadeInUp" data-wow-delay="0.2s"><?php echo e($settings['hero_subtitle'] ?? ''); ?></p>
                            </div>
                            <div class="hero-btn-gold wow fadeInUp" data-wow-delay="0.4s">
                                <a href="<?php echo e(route('contact')); ?>" class="btn-default btn-highlighted"><?php echo e($settings['hero_btn_text'] ?? 'Get In Touch'); ?></a>
                                <a href="<?php echo e(route('services.index')); ?>" class="btn-default">View Our Services</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="hero-image-box-gold wow fadeInUp">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hero-image-title-gold">
                            <h2><?php echo e($settings['site_name'] ?? 'CorpusFeed'); ?></h2>
                        </div>
                        <div class="hero-image-gold">
                            <figure>
                                <?php if(!empty($settings['hero_background'])): ?>
                                    <img src="<?php echo e(asset('storage/'.$settings['hero_background'])); ?>" alt="Hero">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('images/hero-image-gold.png')); ?>" alt="">
                                <?php endif; ?>
                            </figure>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Hero Section End -->

    <!-- About Us Section -->
    <div class="about-us-gold">
        <div class="container">
            <div class="row section-row align-items-center">
                <div class="col-xl-7">
                    <div class="section-title">
                        <h3 class="wow fadeInUp">About Us</h3>
                        <h2 class="text-anime-style-3" data-cursor="-opaque"><?php echo e($settings['about_title'] ?? 'A deep commitment to pure, natural, and eco-friendly practices'); ?></h2>
                    </div>
                </div>
                <div class="col-xl-5">
                    <div class="section-content-btn">
                        <div class="section-title-content wow fadeInUp" data-wow-delay="0.2s">
                            <p><?php echo e($settings['about_body'] ?? ''); ?></p>
                        </div>
                        <div class="section-btn wow fadeInUp" data-wow-delay="0.4s">
                            <a href="<?php echo e(route('about')); ?>" class="btn-default">More About Us</a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-xl-3 col-md-6 order-xl-1 order-md-1">
                    <div class="about-us-item-box-gold mission-box-gold wow fadeInUp" data-wow-delay="0.2s">
                        <div class="about-us-item-gold">
                            <div class="about-us-item-header-gold">
                                <div class="icon-box">
                                    <img src="<?php echo e(asset('images/icon-about-us-item-1-gold.svg')); ?>" alt="">
                                </div>
                                <div class="about-us-item-title-gold">
                                    <h3>Our Mission</h3>
                                </div>
                            </div>
                            <div class="about-us-item-content-gold">
                                <p>To be a modern centre of excellence in circular agribusiness, transforming organic waste into value, reducing post-harvest losses through cold-storage solutions, ensuring a reliable supply of vegetables and herbs, empowering farmers through training and innovation, and producing premium crops for sustainable agriculture and international markets.</p>
                            </div>
                        </div>
                        <div class="about-us-item-body-gold">
                            <div class="about-counter-item-gold">
                                <div class="icon-box">
                                    <img src="<?php echo e(asset('images/icon-about-counter-item-1-gold.svg')); ?>" alt="">
                                </div>
                                <div class="about-counter-item-content-gold">
                                    <h2><span class="counter"><?php echo e($settings['stat_years'] ?? '10'); ?></span>+</h2>
                                    <p>Years of Experience</p>
                                </div>
                            </div>
                            <div class="about-counter-item-gold">
                                <div class="icon-box">
                                    <img src="<?php echo e(asset('images/icon-about-counter-item-2-gold.svg')); ?>" alt="">
                                </div>
                                <div class="about-counter-item-content-gold">
                                    <h2><span class="counter"><?php echo e($settings['stat_clients'] ?? '500'); ?></span>+</h2>
                                    <p>Happy Clients</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-6 col-md-12 order-xl-2 order-md-3">
                    <div class="about-us-image-gold">
                        <figure class="image-anime reveal">
                            <?php if(!empty($settings['about_image'])): ?>
                                <img src="<?php echo e(asset('storage/'.$settings['about_image'])); ?>" alt="About Us">
                            <?php else: ?>
                                <img src="<?php echo e(asset('images/about-us-img-gold.jpg')); ?>" alt="About Us">
                            <?php endif; ?>
                        </figure>
                    </div>
                </div>

                <div class="col-xl-3 col-md-6 order-xl-3 order-md-2">
                    <div class="about-us-item-box-gold vision-box-gold wow fadeInUp" data-wow-delay="0.4s">
                        <div class="about-us-item-gold">
                            <div class="about-us-item-header-gold">
                                <div class="icon-box">
                                    <img src="<?php echo e(asset('images/icon-about-us-item-2-gold.svg')); ?>" alt="">
                                </div>
                                <div class="about-us-item-title-gold">
                                    <h3>Our Vision</h3>
                                </div>
                            </div>
                            <div class="about-us-item-content-gold">
                                <p>To lead in building Kenya’s circular economy by producing organic fertilizers and export-grade vegetables and herbs—creating value from waste, strengthening farmer livelihoods, and protecting the planet.</p>
                            </div>
                        </div>
                        <div class="about-us-item-body-gold">
                            <div class="about-counter-item-gold">
                                <div class="icon-box">
                                    <img src="<?php echo e(asset('images/icon-about-counter-item-1-gold.svg')); ?>" alt="">
                                </div>
                                <div class="about-counter-item-content-gold">
                                    <h2><span class="counter"><?php echo e($settings['stat_farms'] ?? '50'); ?></span>+</h2>
                                    <p>Partner Farms</p>
                                </div>
                            </div>
                            <div class="about-counter-item-gold">
                                <div class="icon-box">
                                    <img src="<?php echo e(asset('images/icon-about-counter-item-2-gold.svg')); ?>" alt="">
                                </div>
                                <div class="about-counter-item-content-gold">
                                    <h2><span class="counter"><?php echo e($settings['stat_deliveries'] ?? '1000'); ?></span>+</h2>
                                    <p>Deliveries Made</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-12 order-4">
                    <div class="section-footer-text wow fadeInUp" data-wow-delay="0.6s">
                        <p><span>Fresh</span> Where Nature Meets Quality &mdash; <a href="<?php echo e(route('services.index')); ?>">Discover our Key Objectives!</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- About Us Section End -->

    <!-- Our Services Section -->
    <?php if($services->count()): ?>
    <div class="our-services-gold bg-section">
        <div class="container">
            <div class="row section-row">
                <div class="col-lg-12">
                    <div class="section-title section-title-center">
                        <h3 class="wow fadeInUp">Our Services</h3>
                        <h2 class="text-anime-style-3" data-cursor="-opaque">Delivering quality services with trusted expertise</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xl-3 col-md-6">
                    <div class="service-item-gold wow fadeInUp" data-wow-delay="<?php echo e($i * 0.2); ?>s">
                        <div class="service-item-image-gold">
                            <a href="<?php echo e(route('services.show', $service->slug)); ?>" data-cursor-text="View">
                                <figure>
                                    <?php if($service->featured_image): ?>
                                        <img src="<?php echo e(asset('storage/'.$service->featured_image)); ?>" alt="<?php echo e($service->title); ?>">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('images/service-image-'.($i+1).'-gold.jpg')); ?>" alt="<?php echo e($service->title); ?>">
                                    <?php endif; ?>
                                </figure>
                            </a>
                        </div>
                        <div class="service-item-body-gold">
                            <div class="service-item-content-gold">
                                <h3><a href="<?php echo e(route('services.show', $service->slug)); ?>"><?php echo e($service->title); ?></a></h3>
                                <p><?php echo e(Str::limit($service->short_description, 100)); ?></p>
                            </div>
                            <div class="service-item-btn-gold">
                                <a href="<?php echo e(route('services.show', $service->slug)); ?>" class="readmore-btn">Read More</a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="our-service-footer-gold">
                        <div class="section-footer-text wow fadeInUp" data-wow-delay="0.8s">
                            <p>Let's make something great together. <a href="<?php echo e(route('contact')); ?>">Get In Touch</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <!-- Our Services Section End -->

    <!-- Our Team Section -->
    <?php if($teamMembers->count()): ?>
    <div style="padding: 80px 0; background: #fff;">
        <div class="container">
            <div class="row section-row">
                <div class="col-lg-12">
                    <div class="section-title section-title-center">
                        <h3 class="wow fadeInUp">Our Team</h3>
                        <h2 class="text-anime-style-3" data-cursor="-opaque">Skilled experts dedicated to excellence and innovation</h2>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <?php $__currentLoopData = $teamMembers->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6 mb-4">
                    <?php echo $__env->make('layouts.partials.team-card', ['member' => $member, 'delay' => $i * 0.2], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="row">
                <div class="col-lg-12 text-center mt-2">
                    <a href="<?php echo e(route('team')); ?>" class="btn-default">View Full Team</a>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <!-- Our Team Section End -->

    <!-- Testimonials Section -->
    <?php if($testimonials->count()): ?>
    <div class="our-testimonials-gold">
        <div class="container">
            <div class="row section-row">
                <div class="col-lg-12">
                    <div class="section-title section-title-center">
                        <h3 class="wow fadeInUp">Testimonials</h3>
                        <h2 class="text-anime-style-3" data-cursor="-opaque">What our clients say about us</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="testimonials-item-list-gold">
                        <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="testimonials-item-gold wow fadeInUp" data-wow-delay="<?php echo e($i * 0.2); ?>s">
                            <div class="testimonials-item-header-gold">
                                <div class="testimonial-item-rating-gold">
                                    <?php for($s = 1; $s <= 5; $s++): ?>
                                        <i class="fa-<?php echo e($s <= $testimonial->rating ? 'solid' : 'regular'); ?> fa-star"></i>
                                    <?php endfor; ?>
                                </div>
                                <div class="testimonial-item-content-gold">
                                    <p>"<?php echo e($testimonial->content); ?>"</p>
                                </div>
                            </div>
                            <div class="testimonial-item-body-gold">
                                <div class="testimonial-author-gold">
                                    <div class="testimonial-author-image-gold">
                                        <figure class="image-anime">
                                            <?php if($testimonial->photo): ?>
                                                <img src="<?php echo e(asset('storage/'.$testimonial->photo)); ?>" alt="<?php echo e($testimonial->name); ?>">
                                            <?php else: ?>
                                                <img src="<?php echo e(asset('images/author-'.($i+1).'.jpg')); ?>" alt="<?php echo e($testimonial->name); ?>">
                                            <?php endif; ?>
                                        </figure>
                                    </div>
                                    <div class="testimonial-author-content-gold">
                                        <h3><?php echo e($testimonial->name); ?></h3>
                                        <p><?php echo e($testimonial->role); ?><?php if($testimonial->company): ?>, <?php echo e($testimonial->company); ?><?php endif; ?></p>
                                    </div>
                                </div>
                                <div class="testimonial-item-quote-gold">
                                    <img src="<?php echo e(asset('images/testimonial-quote-gold.svg')); ?>" alt="">
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <!-- Testimonials Section End -->

    <!-- Latest Blog Section -->
    <?php if($latestPosts->count()): ?>
    <div class="our-blog">
        <div class="container">
            <div class="row section-row">
                <div class="col-lg-12">
                    <div class="section-title section-title-center">
                        <h3 class="wow fadeInUp">Latest Blogs</h3>
                        <h2 class="text-anime-style-3" data-cursor="-opaque">Dive into educational, inspiring, and fresh content</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $latestPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xl-4 col-md-6">
                    <div class="post-item wow fadeInUp" data-wow-delay="<?php echo e($i * 0.2); ?>s">
                        <div class="post-item-box">
                            <div class="post-featured-image">
                                <a href="<?php echo e(route('blog.show', $post->slug)); ?>" data-cursor-text="View">
                                    <figure class="image-anime">
                                        <?php if($post->featured_image): ?>
                                            <img src="<?php echo e(asset('storage/'.$post->featured_image)); ?>" alt="<?php echo e($post->title); ?>">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('images/post-'.($i+1).'.jpg')); ?>" alt="<?php echo e($post->title); ?>">
                                        <?php endif; ?>
                                    </figure>
                                </a>
                            </div>
                            <div class="post-item-content">
                                <h2><a href="<?php echo e(route('blog.show', $post->slug)); ?>"><?php echo e($post->title); ?></a></h2>
                                <p><?php echo e(Str::limit($post->excerpt, 120)); ?></p>
                            </div>
                        </div>
                        <div class="post-item-btn">
                            <a href="<?php echo e(route('blog.show', $post->slug)); ?>" class="readmore-btn">read more</a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="row">
                <div class="col-lg-12 text-center mt-4">
                    <a href="<?php echo e(route('blog.index')); ?>" class="btn-default">View All Posts</a>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <!-- Latest Blog Section End -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER PC\Desktop\corpus-feed\corpusfeed\resources\views\pages\home.blade.php ENDPATH**/ ?>