<?php $__env->startSection('title', 'FAQs'); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h2>FAQs</h2>
        <a href="<?php echo e(route('admin.faqs.create')); ?>" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> Add FAQ</a>
    </div>
    <div class="table-wrapper">
        <table>
            <thead><tr><th>Question</th><th>Category</th><th>Status</th><th>Order</th><th>Actions</th></tr></thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td style="font-weight:500;"><?php echo e(Str::limit($faq->question, 60)); ?></td>
                    <td><?php echo e($faq->category ?? '—'); ?></td>
                    <td><span class="badge <?php echo e($faq->status === 'active' ? 'badge-success' : 'badge-secondary'); ?>"><?php echo e(ucfirst($faq->status)); ?></span></td>
                    <td><?php echo e($faq->order); ?></td>
                    <td>
                        <div style="display:flex;gap:6px;">
                            <a href="<?php echo e(route('admin.faqs.edit', $faq)); ?>" class="btn btn-secondary btn-sm btn-icon"><i class="fa-solid fa-pen"></i></a>
                            <form method="POST" action="<?php echo e(route('admin.faqs.destroy', $faq)); ?>" onsubmit="return confirm('Delete?')">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm btn-icon"><i class="fa-solid fa-trash"></i></button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="5"><div class="empty-state"><i class="fa-solid fa-circle-question"></i><h3>No FAQs</h3><a href="<?php echo e(route('admin.faqs.create')); ?>" class="btn btn-primary" style="margin-top:12px;">Add FAQ</a></div></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER PC\Desktop\corpus-feed\corpusfeed\resources\views\admin\faqs\index.blade.php ENDPATH**/ ?>