<div class="page-header bg-section dark-section parallaxie">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="page-header-box">
                    <h1 class="text-anime-style-3" data-cursor="-opaque"><?php echo e($pageTitle ?? ''); ?></h1>
                    <nav class="wow fadeInUp">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                            <?php if(isset($breadcrumbs)): ?>
                                <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($loop->last): ?>
                                        <li class="breadcrumb-item active" aria-current="page"><?php echo e($bc['label']); ?></li>
                                    <?php else: ?>
                                        <li class="breadcrumb-item"><a href="<?php echo e($bc['url']); ?>"><?php echo e($bc['label']); ?></a></li>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <li class="breadcrumb-item active" aria-current="page"><?php echo e($pageTitle ?? ''); ?></li>
                            <?php endif; ?>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\USER PC\Desktop\corpus-feed\corpusfeed\resources\views\layouts\partials\page-header.blade.php ENDPATH**/ ?>