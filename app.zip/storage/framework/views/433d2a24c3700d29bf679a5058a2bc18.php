<?php $__env->startSection('title', 'FAQs'); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('layouts.partials.page-header', [
        'pageTitle' => 'FAQs',
        'breadcrumbs' => [['label' => 'FAQs', 'url' => route('faqs')]]
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="page-faq">
        <div class="container">
            <div class="row section-row">
                <div class="col-lg-12">
                    <div class="section-title section-title-center">
                        <h3 class="wow fadeInUp">FAQs</h3>
                        <h2 class="text-anime-style-3" data-cursor="-opaque">Frequently asked questions</h2>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-xl-8 offset-xl-2">
                    <?php $__empty_1 = true; $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="faq-item wow fadeInUp" data-wow-delay="<?php echo e(($i % 5) * 0.1); ?>s">
                        <div class="accordion" id="faqAccordion<?php echo e($faq->id); ?>">
                            <div class="accordion-item">
                                <h2 class="accordion-header">
                                    <button class="accordion-button <?php echo e($i > 0 ? 'collapsed' : ''); ?>" type="button"
                                        data-bs-toggle="collapse"
                                        data-bs-target="#collapse<?php echo e($faq->id); ?>"
                                        aria-expanded="<?php echo e($i === 0 ? 'true' : 'false'); ?>">
                                        <?php echo e($faq->question); ?>

                                    </button>
                                </h2>
                                <div id="collapse<?php echo e($faq->id); ?>" class="accordion-collapse collapse <?php echo e($i === 0 ? 'show' : ''); ?>">
                                    <div class="accordion-body">
                                        <?php echo nl2br(e($faq->answer)); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-center">No FAQs available yet.</p>
                    <?php endif; ?>
                </div>
            </div>

            <div class="row mt-5">
                <div class="col-lg-12 text-center">
                    <div class="section-footer-text wow fadeInUp">
                        <p>Still have questions? <a href="<?php echo e(route('contact')); ?>">Contact Us</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER PC\Desktop\corpus-feed\corpusfeed\resources\views\pages\faqs.blade.php ENDPATH**/ ?>