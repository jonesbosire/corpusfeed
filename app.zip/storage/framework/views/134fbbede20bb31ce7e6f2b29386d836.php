<?php $__env->startSection('title', 'Page Not Found'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-404 bg-section dark-section" style="min-height:60vh; display:flex; align-items:center;">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="error-box wow fadeInUp">
                    <h1 style="font-size:120px; font-weight:800; color:var(--primary-color, #5a9e3a);">404</h1>
                    <h2>Oops! Page Not Found</h2>
                    <p>The page you are looking for doesn't exist or has been moved.</p>
                    <div class="mt-4">
                        <a href="<?php echo e(route('home')); ?>" class="btn-default btn-highlighted me-3">Go Home</a>
                        <a href="<?php echo e(route('contact')); ?>" class="btn-default">Contact Us</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER PC\Desktop\corpus-feed\corpusfeed\resources\views\errors\404.blade.php ENDPATH**/ ?>