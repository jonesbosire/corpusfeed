<?php $__env->startSection('title', 'Settings'); ?>
<?php $__env->startSection('content'); ?>

<div style="display:flex;gap:24px;align-items:start;">
    <!-- Group Tabs -->
    <div class="card" style="min-width:200px;">
        <div class="card-header"><h2>Groups</h2></div>
        <div style="padding:8px 0;">
            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('admin.settings.index', $grp)); ?>"
               style="display:block;padding:10px 20px;font-size:14px;text-decoration:none;color:<?php echo e($activeGroup === $grp ? '#fff' : 'var(--text)'); ?>;background:<?php echo e($activeGroup === $grp ? 'var(--primary)' : 'transparent'); ?>;transition:all .15s;">
                <?php echo e(ucfirst($grp)); ?>

            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <!-- Settings Form -->
    <div class="card" style="flex:1;">
        <div class="card-header">
            <h2><?php echo e(ucfirst($activeGroup)); ?> Settings</h2>
        </div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('admin.settings.update')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php $__currentLoopData = $settingItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-group">
                    <label class="form-label"><?php echo e($setting->label); ?></label>
                    <?php if($setting->type === 'image'): ?>
                        <?php if($setting->value): ?>
                        <div style="margin-bottom:10px;">
                            <img src="<?php echo e(asset('storage/'.$setting->value)); ?>" style="max-width:200px;max-height:100px;object-fit:contain;border:2px solid var(--border);border-radius:8px;padding:4px;">
                        </div>
                        <?php endif; ?>
                        <input type="file" name="settings[<?php echo e($setting->key); ?>]" class="form-control" accept="image/*">
                    <?php elseif($setting->type === 'textarea'): ?>
                        <textarea name="settings[<?php echo e($setting->key); ?>]" class="form-control" rows="4"><?php echo e(old('settings.'.$setting->key, $setting->value)); ?></textarea>
                    <?php elseif($setting->type === 'boolean'): ?>
                        <select name="settings[<?php echo e($setting->key); ?>]" class="form-control">
                            <option value="1" <?php echo e($setting->value ? 'selected' : ''); ?>>Yes</option>
                            <option value="0" <?php echo e(!$setting->value ? 'selected' : ''); ?>>No</option>
                        </select>
                    <?php else: ?>
                        <input type="text" name="settings[<?php echo e($setting->key); ?>]" class="form-control"
                            value="<?php echo e(old('settings.'.$setting->key, $setting->value)); ?>">
                    <?php endif; ?>
                    <?php if($setting->help_text): ?>
                    <div class="form-text"><?php echo e($setting->help_text); ?></div>
                    <?php endif; ?>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <input type="hidden" name="group" value="<?php echo e($activeGroup); ?>">
                <button type="submit" class="btn btn-primary">
                    <i class="fa-solid fa-floppy-disk"></i> Save Settings
                </button>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER PC\Desktop\corpus-feed\corpusfeed\resources\views\admin\settings\index.blade.php ENDPATH**/ ?>