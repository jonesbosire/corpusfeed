<?php $__env->startSection('title', 'Our Team'); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('layouts.partials.page-header', [
        'pageTitle' => 'Our Team',
        'breadcrumbs' => [['label' => 'Our Team', 'url' => route('team')]]
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div style="padding: 80px 0;">
        <div class="container">
            <div class="row section-row">
                <div class="col-lg-12">
                    <div class="section-title section-title-center">
                        <h3 class="wow fadeInUp">Our Team</h3>
                        <h2 class="text-anime-style-3" data-cursor="-opaque">Skilled experts dedicated to excellence</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <?php $__empty_1 = true; $__currentLoopData = $teamMembers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-xl-3 col-md-6 mb-4">
                    <?php echo $__env->make('layouts.partials.team-card', ['member' => $member, 'delay' => ($i % 4) * 0.2], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12">
                    <p class="text-center">No team members found.</p>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER PC\Desktop\corpus-feed\corpusfeed\resources\views\pages\team.blade.php ENDPATH**/ ?>