<?php $__env->startSection('title', 'Contact Us'); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('layouts.partials.page-header', [
        'pageTitle' => 'Contact Us',
        'breadcrumbs' => [['label' => 'Contact Us', 'url' => route('contact')]]
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="page-contact-us">
        <div class="container">
            <div class="row section-row">
                <div class="col-lg-12">
                    <div class="section-title section-title-center">
                        <h3 class="wow fadeInUp">Contact Us Today!</h3>
                        <h2 class="text-anime-style-3" data-cursor="-opaque">Let's talk about how we can help you</h2>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-xl-6">
                    <div class="contact-us-image-box wow fadeInUp" data-wow-delay="0.2s">
                        <div class="contact-us-image">
                            <figure class="image-anime">
                                <img src="<?php echo e(asset('images/contact-us-img.jpg')); ?>" alt="Contact Us">
                            </figure>
                        </div>
                        <div class="contact-info-list">
                            <?php if(!empty($settings['contact_phone'])): ?>
                            <div class="contact-info-item">
                                <div class="icon-box">
                                    <img src="<?php echo e(asset('images/icon-phone-primary.svg')); ?>" alt="">
                                </div>
                                <div class="contact-info-item-content">
                                    <h3>Phone Number</h3>
                                    <p><a href="tel:<?php echo e($settings['contact_phone']); ?>"><?php echo e($settings['contact_phone']); ?></a></p>
                                </div>
                            </div>
                            <?php endif; ?>
                            <?php if(!empty($settings['contact_email'])): ?>
                            <div class="contact-info-item">
                                <div class="icon-box">
                                    <img src="<?php echo e(asset('images/icon-mail-primary.svg')); ?>" alt="">
                                </div>
                                <div class="contact-info-item-content">
                                    <h3>Email Address</h3>
                                    <p><a href="mailto:<?php echo e($settings['contact_email']); ?>"><?php echo e($settings['contact_email']); ?></a></p>
                                </div>
                            </div>
                            <?php endif; ?>
                            <?php if(!empty($settings['contact_address'])): ?>
                            <div class="contact-info-item">
                                <div class="icon-box">
                                    <img src="<?php echo e(asset('images/icon-phone-primary.svg')); ?>" alt="">
                                </div>
                                <div class="contact-info-item-content">
                                    <h3>Address</h3>
                                    <p><?php echo e($settings['contact_address']); ?></p>
                                </div>
                            </div>
                            <?php endif; ?>
                            <?php if(!empty($settings['contact_hours'])): ?>
                            <div class="contact-info-item">
                                <div class="icon-box">
                                    <img src="<?php echo e(asset('images/icon-phone-primary.svg')); ?>" alt="">
                                </div>
                                <div class="contact-info-item-content">
                                    <h3>Business Hours</h3>
                                    <p><?php echo e($settings['contact_hours']); ?></p>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="col-xl-6">
                    <div class="contact-us-form">
                        <div class="section-title">
                            <h2 class="text-anime-style-3" data-cursor="-opaque">Get In Touch</h2>
                        </div>

                        <?php if(session('success')): ?>
                        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                        <?php endif; ?>
                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul class="mb-0"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($e); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
                        </div>
                        <?php endif; ?>

                        <div class="contact-form">
                            <form id="contactForm" action="<?php echo e(route('contact.send')); ?>" method="POST" class="wow fadeInUp" data-wow-delay="0.2s">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="form-group col-md-6 mb-4">
                                        <input type="text" name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            placeholder="Your Name *" value="<?php echo e(old('name')); ?>" required>
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group col-md-6 mb-4">
                                        <input type="email" name="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            placeholder="Email Address *" value="<?php echo e(old('email')); ?>" required>
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group col-md-6 mb-4">
                                        <input type="text" name="phone" class="form-control"
                                            placeholder="Phone Number" value="<?php echo e(old('phone')); ?>">
                                    </div>
                                    <div class="form-group col-md-6 mb-4">
                                        <input type="text" name="subject" class="form-control"
                                            placeholder="Subject" value="<?php echo e(old('subject')); ?>">
                                    </div>
                                    <div class="form-group col-md-12 mb-5">
                                        <textarea name="message" class="form-control <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            rows="6" placeholder="Your Message..." required><?php echo e(old('message')); ?></textarea>
                                        <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="contact-form-btn">
                                            <button type="submit" class="btn-default"><span>Send Message</span></button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER PC\Desktop\corpus-feed\corpusfeed\resources\views\pages\contact.blade.php ENDPATH**/ ?>