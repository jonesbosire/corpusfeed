<?php $__env->startSection('title', $post->title); ?>
<?php $__env->startSection('meta_description', $post->meta_description ?: $post->excerpt); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('layouts.partials.page-header', [
        'pageTitle' => $post->title,
        'breadcrumbs' => [
            ['label' => 'Blog', 'url' => route('blog.index')],
            ['label' => $post->title, 'url' => route('blog.show', $post->slug)]
        ]
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="page-blog-single">
        <div class="container">
            <div class="row">
                <div class="col-xl-8">
                    <div class="blog-single-content wow fadeInUp">
                        <!-- Featured Image -->
                        <?php if($post->featured_image): ?>
                        <div class="blog-single-image mb-4">
                            <figure class="image-anime reveal">
                                <img src="<?php echo e(asset('storage/'.$post->featured_image)); ?>" alt="<?php echo e($post->title); ?>" class="img-fluid rounded">
                            </figure>
                        </div>
                        <?php endif; ?>

                        <!-- Post Meta -->
                        <div class="blog-post-meta mb-3">
                            <?php if($post->category): ?>
                            <span class="post-cat me-3">
                                <i class="fa-solid fa-folder"></i>
                                <?php echo e($post->category->name); ?>

                            </span>
                            <?php endif; ?>
                            <span class="post-date me-3">
                                <i class="fa-regular fa-calendar"></i>
                                <?php echo e($post->published_at?->format('F d, Y')); ?>

                            </span>
                            <span class="post-views me-3">
                                <i class="fa-regular fa-eye"></i>
                                <?php echo e($post->views); ?> views
                            </span>
                            <span class="post-read-time">
                                <i class="fa-regular fa-clock"></i>
                                <?php echo e($post->reading_time); ?> min read
                            </span>
                        </div>

                        <!-- Post Body -->
                        <div class="blog-single-body">
                            <?php echo $post->body; ?>

                        </div>

                        <!-- Tags -->
                        <?php if($post->tags->count()): ?>
                        <div class="post-tags mt-4">
                            <strong>Tags:</strong>
                            <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('blog.index', ['tag' => $tag->slug])); ?>" class="tag-badge"><?php echo e($tag->name); ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <?php endif; ?>
                    </div>

                    <!-- Related Posts -->
                    <?php if($relatedPosts->count()): ?>
                    <div class="related-posts mt-5 wow fadeInUp">
                        <h3 class="section-subtitle">Related Posts</h3>
                        <div class="row">
                            <?php $__currentLoopData = $relatedPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6">
                                <div class="post-item">
                                    <div class="post-item-box">
                                        <div class="post-featured-image">
                                            <a href="<?php echo e(route('blog.show', $rp->slug)); ?>">
                                                <figure class="image-anime">
                                                    <?php if($rp->featured_image): ?>
                                                        <img src="<?php echo e(asset('storage/'.$rp->featured_image)); ?>" alt="<?php echo e($rp->title); ?>">
                                                    <?php else: ?>
                                                        <img src="<?php echo e(asset('images/post-1.jpg')); ?>" alt="<?php echo e($rp->title); ?>">
                                                    <?php endif; ?>
                                                </figure>
                                            </a>
                                        </div>
                                        <div class="post-item-content">
                                            <h2><a href="<?php echo e(route('blog.show', $rp->slug)); ?>"><?php echo e($rp->title); ?></a></h2>
                                        </div>
                                    </div>
                                    <div class="post-item-btn">
                                        <a href="<?php echo e(route('blog.show', $rp->slug)); ?>" class="readmore-btn">read more</a>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>

                <div class="col-xl-4">
                    <div class="blog-sidebar">
                        <?php if($categories->count()): ?>
                        <div class="sidebar-widget wow fadeInUp">
                            <h3 class="widget-title">Categories</h3>
                            <ul class="category-list">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a href="<?php echo e(route('blog.index', ['category' => $cat->slug])); ?>">
                                        <?php echo e($cat->name); ?>

                                        <span>(<?php echo e($cat->posts_count); ?>)</span>
                                    </a>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>

                        <?php if($recentPosts->count()): ?>
                        <div class="sidebar-widget wow fadeInUp" data-wow-delay="0.2s">
                            <h3 class="widget-title">Recent Posts</h3>
                            <ul class="recent-posts-list">
                                <?php $__currentLoopData = $recentPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <?php if($rp->featured_image): ?>
                                    <img src="<?php echo e(asset('storage/'.$rp->featured_image)); ?>" alt="<?php echo e($rp->title); ?>">
                                    <?php endif; ?>
                                    <div>
                                        <a href="<?php echo e(route('blog.show', $rp->slug)); ?>"><?php echo e(Str::limit($rp->title, 50)); ?></a>
                                        <span><?php echo e($rp->published_at?->format('M d, Y')); ?></span>
                                    </div>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER PC\Desktop\corpus-feed\corpusfeed\resources\views\pages\blog\show.blade.php ENDPATH**/ ?>