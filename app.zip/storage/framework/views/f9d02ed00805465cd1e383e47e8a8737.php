<?php $__env->startSection('title', 'Subscribers'); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h2>Newsletter Subscribers</h2>
        <a href="<?php echo e(route('admin.subscribers.export')); ?>" class="btn btn-secondary btn-sm">
            <i class="fa-solid fa-download"></i> Export CSV
        </a>
    </div>
    <div class="table-wrapper">
        <table>
            <thead><tr><th>Email</th><th>Name</th><th>Status</th><th>Subscribed</th><th>Actions</th></tr></thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $subscribers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td style="font-weight:500;"><?php echo e($sub->email); ?></td>
                    <td><?php echo e($sub->name ?? '—'); ?></td>
                    <td><span class="badge <?php echo e($sub->status === 'active' ? 'badge-success' : 'badge-secondary'); ?>"><?php echo e(ucfirst($sub->status)); ?></span></td>
                    <td><?php echo e($sub->created_at->format('M d, Y')); ?></td>
                    <td>
                        <form method="POST" action="<?php echo e(route('admin.subscribers.destroy', $sub)); ?>" onsubmit="return confirm('Remove this subscriber?')">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm btn-icon"><i class="fa-solid fa-trash"></i></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="5"><div class="empty-state"><i class="fa-solid fa-at"></i><h3>No subscribers yet</h3></div></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($subscribers->hasPages()): ?>
    <div style="padding:16px 24px;"><?php echo e($subscribers->links()); ?></div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER PC\Desktop\corpus-feed\corpusfeed\resources\views\admin\subscribers\index.blade.php ENDPATH**/ ?>