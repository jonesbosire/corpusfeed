<?php $__env->startSection('title', 'Testimonials'); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h2>Testimonials</h2>
        <a href="<?php echo e(route('admin.testimonials.create')); ?>" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> Add Testimonial</a>
    </div>
    <div class="table-wrapper">
        <table>
            <thead><tr><th>Name</th><th>Role / Company</th><th>Rating</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td style="font-weight:500;"><?php echo e($t->name); ?></td>
                    <td><?php echo e($t->role); ?><?php if($t->company): ?>, <?php echo e($t->company); ?><?php endif; ?></td>
                    <td>
                        <?php for($s=1;$s<=5;$s++): ?>
                            <i class="fa-<?php echo e($s <= $t->rating ? 'solid' : 'regular'); ?> fa-star" style="color:#f59e0b;font-size:12px;"></i>
                        <?php endfor; ?>
                    </td>
                    <td><span class="badge <?php echo e($t->status === 'active' ? 'badge-success' : 'badge-secondary'); ?>"><?php echo e(ucfirst($t->status)); ?></span></td>
                    <td>
                        <div style="display:flex;gap:6px;">
                            <a href="<?php echo e(route('admin.testimonials.edit', $t)); ?>" class="btn btn-secondary btn-sm btn-icon"><i class="fa-solid fa-pen"></i></a>
                            <form method="POST" action="<?php echo e(route('admin.testimonials.destroy', $t)); ?>" onsubmit="return confirm('Delete?')">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm btn-icon"><i class="fa-solid fa-trash"></i></button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="5"><div class="empty-state"><i class="fa-solid fa-star"></i><h3>No testimonials</h3><a href="<?php echo e(route('admin.testimonials.create')); ?>" class="btn btn-primary" style="margin-top:12px;">Add Testimonial</a></div></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER PC\Desktop\corpus-feed\corpusfeed\resources\views\admin\testimonials\index.blade.php ENDPATH**/ ?>