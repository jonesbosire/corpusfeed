<?php $__env->startSection('title', 'Message from ' . $message->name); ?>
<?php $__env->startSection('content'); ?>
<div class="card" style="max-width:760px;">
    <div class="card-header">
        <h2>Message Details</h2>
        <div style="display:flex;gap:8px;">
            <?php if($message->status !== 'replied'): ?>
            <form method="POST" action="<?php echo e(route('admin.messages.updateStatus', $message)); ?>">
                <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                <input type="hidden" name="status" value="replied">
                <button type="submit" class="btn btn-primary btn-sm"><i class="fa-solid fa-check-double"></i> Mark Replied</button>
            </form>
            <?php endif; ?>
            <a href="<?php echo e(route('admin.messages.index')); ?>" class="btn btn-secondary btn-sm">Back</a>
        </div>
    </div>
    <div class="card-body">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:24px;padding-bottom:24px;border-bottom:1px solid var(--border);">
            <div>
                <div class="form-text">From</div>
                <strong><?php echo e($message->name); ?></strong>
            </div>
            <div>
                <div class="form-text">Email</div>
                <a href="mailto:<?php echo e($message->email); ?>"><?php echo e($message->email); ?></a>
            </div>
            <?php if($message->phone): ?>
            <div>
                <div class="form-text">Phone</div>
                <span><?php echo e($message->phone); ?></span>
            </div>
            <?php endif; ?>
            <div>
                <div class="form-text">Date</div>
                <span><?php echo e($message->created_at->format('F d, Y H:i')); ?></span>
            </div>
            <div>
                <div class="form-text">Status</div>
                <?php if($message->status === 'unread'): ?>
                    <span class="badge badge-danger">Unread</span>
                <?php elseif($message->status === 'read'): ?>
                    <span class="badge badge-info">Read</span>
                <?php else: ?>
                    <span class="badge badge-success">Replied</span>
                <?php endif; ?>
            </div>
            <?php if($message->subject): ?>
            <div>
                <div class="form-text">Subject</div>
                <strong><?php echo e($message->subject); ?></strong>
            </div>
            <?php endif; ?>
        </div>

        <div>
            <div class="form-text" style="margin-bottom:8px;">Message</div>
            <div style="background:#f9fafb;border-radius:8px;padding:16px;font-size:15px;line-height:1.6;white-space:pre-wrap;"><?php echo e($message->message); ?></div>
        </div>

        <div style="margin-top:24px;">
            <a href="mailto:<?php echo e($message->email); ?>?subject=Re: <?php echo e($message->subject ?? 'Your message'); ?>" class="btn btn-primary">
                <i class="fa-solid fa-reply"></i> Reply via Email
            </a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER PC\Desktop\corpus-feed\corpusfeed\resources\views\admin\messages\show.blade.php ENDPATH**/ ?>