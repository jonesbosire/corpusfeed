@extends('layouts.app')

@section('title', 'About Us')

@section('content')

    @include('layouts.partials.page-header', [
        'pageTitle' => 'About Us',
        'breadcrumbs' => [['label' => 'About Us', 'url' => route('about')]]
    ])

    <!-- About Us Section -->
    <div class="about-us-gold">
        <div class="container">
            <div class="row section-row align-items-center">
                <div class="col-xl-7">
                    <div class="section-title">
                        <h3 class="wow fadeInUp">About Us</h3>
                        <h2 class="text-anime-style-3" data-cursor="-opaque">{{ $settings['about_title'] ?? 'A deep commitment to pure, natural, and eco-friendly practices' }}</h2>
                    </div>
                </div>
                <div class="col-xl-5">
                    <div class="section-content-btn">
                        <div class="section-title-content wow fadeInUp" data-wow-delay="0.2s">
                            <p>{{ $settings['about_body'] ?? '' }}</p>
                        </div>
                        <div class="section-btn wow fadeInUp" data-wow-delay="0.4s">
                            <a href="{{ route('contact') }}" class="btn-default">Get In Touch</a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-xl-6">
                    <div class="about-us-image-gold">
                        <figure class="image-anime reveal">
                            @if(!empty($settings['about_image']))
                                <img src="{{ asset('storage/'.$settings['about_image']) }}" alt="About Us">
                            @else
                                <img src="{{ asset('images/about-us-img-gold.jpg') }}" alt="About Us">
                            @endif
                        </figure>
                    </div>
                </div>
                <div class="col-xl-6">
                    <div class="why-choose-us-content-gold">
                        <div class="section-title">
                            <h3 class="wow fadeInUp">Why Choose Us</h3>
                            <h2 class="text-anime-style-3" data-cursor="-opaque">Key Objectives</h2>
                        </div>
                        <div class="why-choose-item-list-gold wow fadeInUp" data-wow-delay="0.4s">
                            
                                <div class="why-choose-item-content-gold">
                                    <p>Promote circular economy practices by transforming organic waste into high-quality organic fertilizers and soil-enhancing inputs.</p>
                                </div>

                                <div class="why-choose-item-content-gold">
                                    <p>Establish a centre of excellence for the production of export-grade vegetables and herbs through innovation, quality assurance, and cold-chain solutions.</p>
                                </div>

                                <div class="why-choose-item-content-gold">
                                    <p>Ensure a reliable and consistent supply of premium-quality vegetables and herbs that meet international export standards, strengthening Kenya’s competitiveness in regional and global markets.</p>
                                </div>
                            
                        </div>
                    </div>
                </div>
            </div>

            <!-- Stats Row -->
            {{-- <div class="row mt-5">
                <div class="col-md-3 col-6">
                    <div class="about-counter-item-gold wow fadeInUp text-center">
                        <h2><span class="counter">{{ $settings['stat_clients'] ?? '500' }}</span>+</h2>
                        <p>Happy Clients</p>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="about-counter-item-gold wow fadeInUp text-center" data-wow-delay="0.2s">
                        <h2><span class="counter">{{ $settings['stat_farms'] ?? '50' }}</span>+</h2>
                        <p>Partner Farms</p>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="about-counter-item-gold wow fadeInUp text-center" data-wow-delay="0.4s">
                        <h2><span class="counter">{{ $settings['stat_years'] ?? '10' }}</span>+</h2>
                        <p>Years Experience</p>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="about-counter-item-gold wow fadeInUp text-center" data-wow-delay="0.6s">
                        <h2><span class="counter">{{ $settings['stat_deliveries'] ?? '1000' }}</span>+</h2>
                        <p>Deliveries Made</p>
                    </div>
                </div>
            </div> --}}
        </div>
    </div>

    <!-- Team Section Preview -->
    @if($teamMembers->count())
    <div style="padding: 80px 0; background: #f8f9f7;">
        <div class="container">
            <div class="row section-row">
                <div class="col-lg-12">
                    <div class="section-title section-title-center">
                        <h3 class="wow fadeInUp">Meet Our Team</h3>
                        <h2 class="text-anime-style-3" data-cursor="-opaque">The people behind our success</h2>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                @foreach($teamMembers->take(4) as $i => $member)
                <div class="col-xl-3 col-md-6 mb-4">
                    @include('layouts.partials.team-card', ['member' => $member, 'delay' => $i * 0.2])
                </div>
                @endforeach
            </div>
            <div class="row">
                <div class="col-lg-12 text-center mt-2">
                    <a href="{{ route('team') }}" class="btn-default">View All Team Members</a>
                </div>
            </div>
        </div>
    </div>
    @endif

@endsection
