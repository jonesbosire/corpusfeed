@extends('layouts.app')

@section('title', $service->title)
@section('meta_description', $service->short_description)

@section('content')

    @include('layouts.partials.page-header', [
        'pageTitle' => $service->title,
        'breadcrumbs' => [
            ['label' => 'Services', 'url' => route('services.index')],
            ['label' => $service->title, 'url' => route('services.show', $service->slug)]
        ]
    ])

    <div class="page-service-single">
        <div class="container">
            <div class="row">
                <div class="col-xl-8">
                    <div class="service-single-content wow fadeInUp">
                        @if($service->featured_image)
                        <div class="service-single-image mb-4">
                            <figure class="image-anime reveal">
                                <img src="{{ asset('storage/'.$service->featured_image) }}" alt="{{ $service->title }}" class="img-fluid rounded">
                            </figure>
                        </div>
                        @endif

                        <div class="service-single-body">
                            {!! $service->body !!}
                        </div>
                    </div>
                </div>

                <div class="col-xl-4">
                    <!-- Sidebar -->
                    <div class="service-sidebar wow fadeInUp" data-wow-delay="0.2s">
                        <!-- All Services -->
                        @if($allServices->count())
                        <div class="sidebar-widget">
                            <h3 class="widget-title">All Services</h3>
                            <ul class="services-list">
                                @foreach($allServices as $s)
                                <li class="{{ $s->id === $service->id ? 'active' : '' }}">
                                    <a href="{{ route('services.show', $s->slug) }}">{{ $s->title }}</a>
                                </li>
                                @endforeach
                            </ul>
                        </div>
                        @endif

                        <!-- Contact Box -->
                        <div class="sidebar-widget sidebar-contact-box">
                            <h3>Need Help?</h3>
                            <p>Contact us for more information about our services.</p>
                            <a href="{{ route('contact') }}" class="btn-default">Contact Us</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection
